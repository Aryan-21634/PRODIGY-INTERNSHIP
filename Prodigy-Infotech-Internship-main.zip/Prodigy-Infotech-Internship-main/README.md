The Prodigy Infotech Online internship has recently concluded, spanning a duration of one month from 1st February to 29th February. Throughout this internship, I had the opportunity to delve into various aspects of web development, particularly focusing on HTML, CSS, and JavaScript. The internship was conducted entirely online, allowing for flexibility and convenience in completing the assigned tasks.

INTERSHIP DURATION: 1 MONTHS [1 FEB - 29 FEB]


MODE: ONLINE

LANGUAGES : HTML,CSS,JAVASCRIPT

OFFER LETTER:-

![OFFER LETTER](https://github.com/Arvindvadivelu/Prodigy-Infotech/assets/129649393/1003df5a-3dd6-4a77-a8b9-3c32c5b71644)

5 TASKS :-

TASK 1: RESPONSIVE LANDING PAGE:-

WEBSITE: [https://carscrubz.netlify.app/](https://carscrubz.netlify.app/)

![01](https://github.com/Arvindvadivelu/Prodigy-Infotech/assets/129649393/a286ee32-6540-4cb6-a41b-b2199e22df6b)

TASK 2: STOPWATCH WEB APPLICATION:-

WEBSITE: [https://prodigytimer.netlify.app/](https://prodigytimer.netlify.app/)

![01](https://github.com/Arvindvadivelu/Prodigy-Infotech/assets/129649393/25b206ad-0660-4889-95cd-dcc906376f17)

TASK 3: TIC-TAC-TOC WEB APPLICATION:-

WEBSITE: [https://ticktacktok.netlify.app/](https://ticktacktok.netlify.app/)

![02](https://github.com/Arvindvadivelu/Prodigy-Infotech/assets/129649393/7ea5371c-9798-4e21-9ce0-8aee482ea448)

TASK 5: WEATHER APPLICATION:-

WEBSITE: [https://weatherpocket.netlify.app/](https://weatherpocket.netlify.app/)

![02](https://github.com/Arvindvadivelu/Prodigy-Infotech/assets/129649393/0f8351a5-9067-45f1-929d-eb753358ac99)

