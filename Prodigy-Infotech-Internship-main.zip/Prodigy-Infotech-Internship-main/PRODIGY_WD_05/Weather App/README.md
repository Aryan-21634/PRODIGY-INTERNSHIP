TASK 5 : WEATHER APPLICATION

PAGE NAME : Weather app

WEBSITE: https://weatherpocket.netlify.app/

DESCRIPTION:-
- Develop a webpage that retrieves weather information from a weather API, either based on the user's location or a location entered by the user.
- Present the current weather conditions, temperature, and other pertinent details on the webpage.
- Construct a web page that utilizes a weather API to gather weather data, considering the user's location or a location provided by the user.
- Showcase the present weather conditions, temperature, and other pertinent information on the webpage.
- Create a webpage that connects to a weather API to obtain weather data, using either the user's location or a location specified by the user.
- Exhibit the current weather conditions, temperature, and other relevant details on the webpage.
- Design a web page that retrieves weather data from a weather API, based on either the user's location or a location entered by the user.
- Show the current weather conditions, temperature, and other relevant information on the webpage.
- Develop a webpage that utilizes a weather API to fetch weather data, considering the user's location or a location provided by the user.
- Display the current weather conditions, temperature, and other pertinent details on the webpage.

SCREENSHOT OF THE WEBSITE:-

![01](https://github.com/Arvindvadivelu/Prodigy-Infotech/assets/129649393/7909de4d-f779-4a66-bd71-6d83ec910c49)
  
![02](https://github.com/Arvindvadivelu/Prodigy-Infotech/assets/129649393/e430448e-48d2-4830-abb4-489e8653bc78)

![03](https://github.com/Arvindvadivelu/Prodigy-Infotech/assets/129649393/ee329008-9565-46e0-8567-d76c53b4db19)
